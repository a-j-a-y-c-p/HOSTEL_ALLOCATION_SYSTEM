package com.example.birthdates;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.content.Intent;
import android.widget.Toast;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
public class MainActivity extends AppCompatActivity {
    EditText etName, etbdate,etcdate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//Object Creation of the two Edittext components
        etName = (EditText) findViewById(R.id.name);
        etbdate = (EditText) findViewById(R.id.bdate);
        etcdate = (EditText) findViewById(R.id.cdate);
    }

    //Following are the click events of all the buttons

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static String calcAge(String bdate, String cdate)
    {
        LocalDate Dob = LocalDate.parse(bdate);
        LocalDate currentDate = LocalDate.parse(cdate);
        Period period = Dob.until(currentDate);
        int age = period.getYears();
        return Integer.toString(age);
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void AddRecord(View v) throws Exception {

        String name = etName.getText().toString().trim();
        String bdate = etbdate.getText().toString().trim();
        String cdate = etcdate.getText().toString().trim();
        if(name.equals("")||bdate.equals("")||cdate.equals("")){
            Toast.makeText(this,"Fill all the credentials", Toast.LENGTH_LONG).show();
        }
        else {
            String age = calcAge(bdate, cdate);
            //Following Code invokes the methods: open(), insertRecord() and close() of BDatesDB class
            try {
                BDatesDB db = new BDatesDB(this);
                db.open();
                db.insertRecord(name, bdate, age);
                Toast.makeText(this, "Successfully added!..", Toast.LENGTH_LONG).show();
                etName.setText("");
                etbdate.setText("");
                etcdate.setText("");
                db.close();
            } catch (SQLException e) {
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    //Following Code invokes the methods: open(), deleteRecord() and close() of BDatesDB class
    public void DeleteRecord(View v) throws Exception {
        try {
            BDatesDB db = new BDatesDB(this);
            db.open();
            db.deleteRecord("1");
            Toast.makeText(this, "Successfully Deleted!..", Toast.LENGTH_LONG).show();
            db.close();
        } catch (
                SQLException e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    //Following Code invokes the methods: open(), updateRecord() and close() of BDatesDB class
    public void UpdateRecord(View v) throws Exception {
        try {
            BDatesDB db = new BDatesDB(this);
            db.open();
            db.updateRecord("1", "Mayuri", "1979-12-26",Integer.toString(43));
            Toast.makeText(this, "Successfully updated!..", Toast.LENGTH_LONG).show();
            db.close();
        } catch (
                SQLException e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /*Following Code opens the activity_data.xml file, data.java file contains the code for
    displaying the records on textview */
    public void ShowRecord(View view) {
        Intent intent = new Intent(MainActivity.this, data.class);
        startActivity(intent);
    }

    /*Following Code opens the activity_d_o_b_list.xml file, DOBList.java file contains the code
    for displaying the records on Listview*/
    public void DisplayList(View view) {
        Intent intent = new Intent(MainActivity.this, DOBList.class);
        startActivity(intent);
    }
}