package com.example.studentcorner;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
public class student extends AppCompatActivity {
    EditText e;
    TextView OurText;
    int num;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);
        ActionBar actionbar = getSupportActionBar();
        actionbar.setIcon(R.mipmap.student_corner);
        actionbar.setTitle(" Student Activity");
        actionbar.setDisplayUseLogoEnabled(true);
        actionbar.setDisplayShowHomeEnabled(true);
        actionbar.setDisplayHomeAsUpEnabled(true);
        e= findViewById(R.id.editText);
        OurText = findViewById(R.id.textView);
    }

    public void displayOnCLick(View v) {
// Complete the logic here…
        String s = e.getText().toString();

        if (s.equals(null)) {
            String result = "Please enter a value";
            OurText.setText(result);
        } else {
            num= Integer.parseInt(s);
            String g="Invalid Value";
            if(num==1){
               g="Name:Robert Downey\n ID:BT20CSE001";
            }
            else if(num==2){
                g="Name:Peter Parker\n ID:BT20CSE002";
            }
            else if(num==3){
                g="Name:Steve Rogers\n ID:BT20CSE003";
            }
            else if(num==5){
                g="Name:Natasha Romanoff\n ID:BT20CSE004";
            }
            else if(num==5){
                g="Name:Thor Odinson\n ID:BT20CSE005";
            }
            OurText.setText(g);
        }
    }
}