package com.example.studentcorner;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Grade extends AppCompatActivity {
    EditText e;
    TextView OurText;
    int num;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grade);
        ActionBar actionbar = getSupportActionBar();
        actionbar.setIcon(R.mipmap.student_corner);
        actionbar.setTitle(" Grades");
        actionbar.setDisplayUseLogoEnabled(true);
        actionbar.setDisplayShowHomeEnabled(true);
        actionbar.setDisplayHomeAsUpEnabled(true);
        e= findViewById(R.id.editText);
        OurText = findViewById(R.id.textView);
    }
    public void calGradeOnClick(View v){
// Complete the logic here…
        String s = e.getText().toString();

        if (s.equals(null)) {
            String result = "Please enter a value";
            OurText.setText(result);
        } else {
            num= Integer.parseInt(s);
            String g;
            g="INVALID";
            if(num<=100 && num>90){
               g="A+";
            }
            else if(num<=90 && num>80){
                g="A";
            }
            else if(num<=80 && num>70){
                g="B+";
            }
            else if(num<=70 && num>60){
                g="B";
            }
            else if(num<=60 && num>50){
                g="C+";
            }
            else if(num<=50 && num>40){
                g="C";
            }
            else if(num<=40 && num>30){
                g="D";
            }
            else if(num<=30 && num>=0){
                g="F";
            }
            OurText.setText(g);
        }

    }
}