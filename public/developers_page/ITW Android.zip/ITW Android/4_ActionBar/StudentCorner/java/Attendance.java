package com.example.studentcorner;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Attendance extends AppCompatActivity {
    EditText e;
    TextView OurText;
    int num;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);
        ActionBar actionbar = getSupportActionBar();
        actionbar.setIcon(R.mipmap.student_corner);
        actionbar.setTitle(" Attendance Record");
        actionbar.setDisplayUseLogoEnabled(true);
        actionbar.setDisplayShowHomeEnabled(true);
        actionbar.setDisplayHomeAsUpEnabled(true);
        e= findViewById(R.id.editText);
        OurText = findViewById(R.id.textView);
    }
    public void displayAttenOnClick(View v){
// Complete the logic here…
        String s = e.getText().toString();

        if (s.equals(null)) {
            String result = "Please enter a value";
            OurText.setText(result);
        } else {
            num= Integer.parseInt(s);
            double sum = num/2.50;
            OurText.setText(Double.toString(sum));
        }
    }
}