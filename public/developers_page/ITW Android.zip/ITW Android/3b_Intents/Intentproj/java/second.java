package com.example.intentproj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class second extends AppCompatActivity {
    Button display;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        display= (Button)findViewById(R.id.button3);
    }
    /*public void Next(View view){
        Intent i = new Intent(second.this,third.class);
        i.putExtra("Name","WELCOME");
        startActivity(i);
    }*/
    public void gotoGoogle(View view) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.google.com"));
        startActivity(i);
    }
    public void gotoWiki(View view) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://en.wikipedia.org/wiki/Main_Page"));
        startActivity(i);
    }
    /*public void gotoThird(View view){
        Intent i = new Intent(second.this, third.class);
        startActivity(i);
    }*/
    public void gotoThird(View view){

            Intent intent = new Intent(getApplicationContext(),third.class);
            intent.putExtra("message_key", "WELCOME TO IIITN");
            startActivity(intent);

    }
}