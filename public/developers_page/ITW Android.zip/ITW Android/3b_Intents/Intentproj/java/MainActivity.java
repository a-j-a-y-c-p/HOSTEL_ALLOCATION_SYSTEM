package com.example.intentproj;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    /*Implicit Intents: opens a page based on the data passed aling with intent object and
    Action tells what action has to be done on the opening page.*/
    public void gotoIIITN(View view){
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://iiitn.ac.in/"));
        startActivity(i);
    }
    public void gotoSecond(View view){
        Intent i = new Intent(MainActivity.this, second.class);
        startActivity(i);
    }

}